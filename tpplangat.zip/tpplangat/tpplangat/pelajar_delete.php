<?php
 include('config.php');
 $id = $_GET['id'];
 $sql = "DELETE FROM info_pelajar WHERE id= '$id'";
 $result = mysqli_query($conn, $sql);
 if ($result)
     echo "<script>alert('Berjaya dipadam')</script>";
else 
   echo "<script>alert('Tidak berjaya padam rekod')</script>";
echo "<script>window.location='index.php'</script>";
?>