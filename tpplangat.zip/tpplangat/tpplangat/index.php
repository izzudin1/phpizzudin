<?php
include ('config.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <a href="style.css"></a>
    
</head>

<body>
    <center>
        <table border="1">
            <caption>SENARAI NAMA PELAJAR</caption>
            <tr>
                <td class="head">Id</td>
                <td class="head">NDP</td>
                <td class="head">Nama Pelajar</td>
                <td class="head">No_KP</td>
                <td class="head">Jantina</td>
                <td class="head">No_HP</td>
                <td class="head"></td>
            </tr>
            <?php
            $sql = "SELECT * FROM info_pelajar ORDER BY id ASC";
            $data = mysqli_query($conn, $sql);
            $bil = 1;
            while ($pelajar = mysqli_fetch_array($data)){
                ?>
                <tr>
                  
                    <td><?php echo $pelajar['id']; ?></td>
                    <td><?php echo $pelajar['no_ndp']; ?></td>
                    <td><?php echo $pelajar['nama_pelajar']; ?></td>
                    <td><?php echo $pelajar['no_kp']; ?></td>
                    <td><?php echo $pelajar['jantina']; ?></td>
                    <td><?php echo $pelajar['nohp']; ?></td>
                    <td>
                       
                        <a href="pelajar_delete.php?id=<?php echo $pelajar['id'];?>">
                            <h4>padam</h4> </a>
                    </td> 
                </tr> 
            <?php $bil = $bil + 1; 
            } 
            ?> 
        </table>
        <button><a href="tambah_pelajar.php">Tambah pelajar</a></button>
    </center>
</body>

</html>