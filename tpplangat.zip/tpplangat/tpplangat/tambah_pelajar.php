<?php
include('config.php'); 
if(isset($_POST['no_ndp'])) {    
    $id = $_POST['id'];
    $no_ndp = $_post['no_ndp'];
    $nama_pelajar = $_POST['nama_pelajar'];
    $no_kp = $_POST['no_kp'];
    $jantina = $_POST['jantina'];
	$nohp = $_POST['nohp'];
    $sql = "INSERT INTO info_pelajar (id, no_ndp, nama_pelajar, no_kp, jantina, nohp)
    VALUES ('$id', '$no_ndp', '$nama_pelajar', '$no_kp', '$jantina', '$nohp')";
    $result = mysqli_query($conn, $sql); 
    if ($result)
        echo "<script>alert('Berjaya kemaskini')</script>";
    else 
        echo "<script>alert('Tidak berjaya kemaskini')</script>";
    echo "<script>window.location='index.php'</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <a href="style.css"></a>
</head>
<body>
    <center>
    <form action="tambah_pelajar.php" method="POST">
        <table>
            <tr>
                <td class=warna> Id </td>
                <td> <input required type="text" name="id" placeholder="001"> </td>
            </tr>
            <tr>
                <td class=warna> ndp </td>
                <td> <input required type="text" name="no_ndp" placeholder="23221020"> </td>
            </tr>
            <tr>
                <td class=warna> Nama Pelajar </td>
                <td> <input required type="text" name="nama_pelajar" placeholder="pelajar"> </td>
            </tr>
            <tr>
                <td class=warna> No Kad Pengenalan </td>
                <td> <input required type="text" name="no_kp" placeholder="020108010509"></td>
            </tr>
            <tr>
                <td class=warna> Jantina</td>
                <td> <input required type="text" name="jantina" placeholder="Lelaki/Perempuan"></td>
            </tr>
            <tr>
                <td class=warna> Nombor Telefon</td>
                <td> <input required type="text" name="nohp" placeholder="0112233445566"></td>
            </tr>
            <tr>
                <td class=warna> Emel</td>
                <td> <input required type="text" name="emel" placeholder="Emel"></td>
            </tr>
            <tr>
                <td class=warna> Alamat</td>
                <td> <input required type="text" name="Alamat" placeholder="Alamat"></td>
            </tr>
        </table>
        <button type="submit">Simpan</button>
    </form>
    </center>
</body>
</html>